ShopMetrics Project - Setup Notes

1. Install/start WampServer and make sure Apache and MySQL are running.
2. Copy the shopmetrics folder into C:\wamp64\www\shopmetrics.
3. Confirm schema.sql is directly inside the shopmetrics folder.
4. Open http://localhost/shopmetrics/ in your browser.
5. On first API request, database.php attempts to create the shopmetrics database and import schema.sql if none of the required tables exist.
6. MySQL credentials are set to host 127.0.0.1, user root, blank password. Change these in backend/config/database.php if your local MySQL credentials differ.

Important safety note:
- Do not re-import schema.sql into an existing database: it contains DROP TABLE statements.
- Automatic setup imports the dump only when all four required tables are absent. If some but not all required tables exist, it stops with an error rather than overwriting existing data.
- This ZIP has not been tested on a separate computer. The target computer must have PHP PDO MySQL and mysqli extensions enabled in WampServer.
