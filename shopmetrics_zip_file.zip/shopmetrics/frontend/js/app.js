let purchaseChart = null;
let dashboardData = null;

const API_BASE = "../backend/api";

/* =========================
   LOAD DASHBOARD
========================= */

async function loadDashboard() {
    try {
        const response = await fetch(`${API_BASE}/dashboard.php`);

        if (!response.ok) {
            throw new Error(`Dashboard HTTP error: ${response.status}`);
        }

        const result = await response.json();
        console.log("Dashboard API:", result);

        if (!result.success) {
            throw new Error("Dashboard API failed");
        }

        dashboardData = result;

        const kpi = result.kpis || {};

        setText("visitors", kpi.users ?? 0);
        setText("productViews", kpi.sessions ?? 0);
        setText("cartAdds", kpi.orders ?? 0);
        setText("checkouts", kpi.orders ?? 0);
        setText("purchases", kpi.orders ?? 0);

        setText(
            "revenue",
            "₹" + Number(kpi.revenue ?? 0).toLocaleString("en-IN")
        );

        setText("conversionRate", `${kpi.conversion_rate ?? 0}%`);
        setText("cartAbandonment", `${kpi.cart_abandonment ?? 0}%`);

        loadTrafficSources(result.traffic_sources);
        loadDevices(result.devices);
        loadDailyPerformance(result.daily);
        createPurchaseChart(result.daily);

    } catch (error) {
        console.error("Dashboard error:", error);
    }
}

/* =========================
   HELPER: UPDATE TEXT
========================= */

function setText(id, value) {
    const element = document.getElementById(id);

    if (element) {
        element.textContent = value;
    }
}

/* =========================
   LOAD FUNNEL API
========================= */

async function loadFunnelData() {
    try {
        const response = await fetch(`${API_BASE}/funnel.php`);

        if (!response.ok) {
            throw new Error(`Funnel HTTP error: ${response.status}`);
        }

        const result = await response.json();
        console.log("Funnel API:", result);

        if (!result.success || !Array.isArray(result.funnel)) {
            throw new Error("Invalid funnel API response");
        }

        result.funnel.forEach(item => {
            const count = item.count;

            if (item.stage === "Visitors") {
                setText("funnelVisitors", count);
                setText("visitors", count);
            } else if (item.stage === "Product Views") {
                setText("funnelViews", count);
                setText("productViews", count);
            } else if (item.stage === "Add to Cart") {
                setText("funnelCart", count);
                setText("cartAdds", count);
            } else if (item.stage === "Checkout") {
                setText("funnelCheckout", count);
                setText("checkouts", count);
            } else if (
                item.stage === "Purchases" ||
                item.stage === "Purchase"
            ) {
                setText("funnelPurchase", count);
                setText("purchases", count);
            }
        });

    } catch (error) {
        console.error("Funnel error:", error);
    }
}

/* =========================
   LOAD PRODUCTS
========================= */

async function loadProducts() {
    const tableBody = document.getElementById("productsTable");

    if (!tableBody) {
        console.error("Products table element not found.");
        return;
    }

    try {
        const response = await fetch(`${API_BASE}/products.php`);

        if (!response.ok) {
            throw new Error(`Products HTTP error: ${response.status}`);
        }

        const result = await response.json();
        console.log("Products API:", result);

        if (!result.success) {
            throw new Error("Products API failed");
        }

        tableBody.replaceChildren();

        if (!Array.isArray(result.products) || result.products.length === 0) {
            tableBody.innerHTML = `
                <tr>
                    <td colspan="6">No products found.</td>
                </tr>
            `;
            return;
        }

        result.products.forEach(product => {
            const row = document.createElement("tr");

            const values = [
                product.name,
                product.category,
                "₹" + Number(product.price ?? 0).toLocaleString("en-IN"),
                product.views ?? 0,
                product.cart_adds ?? 0,
                product.units_sold ?? 0
            ];

            values.forEach(value => {
                const cell = document.createElement("td");
                cell.textContent = value ?? "";
                row.appendChild(cell);
            });

            tableBody.appendChild(row);
        });

    } catch (error) {
        console.error("Products error:", error);

        tableBody.innerHTML = `
            <tr>
                <td colspan="6">
                    Unable to load products. Check the browser console.
                </td>
            </tr>
        `;
    }
}

/* =========================
   TRAFFIC SOURCES
========================= */

function loadTrafficSources(sources) {
    const container = document.getElementById("trafficSources");

    if (!container) return;

    container.replaceChildren();

    if (!Array.isArray(sources) || sources.length === 0) {
        container.textContent = "No traffic data available.";
        return;
    }

    const max = Math.max(
        ...sources.map(item => Number(item.sessions) || 0),
        1
    );

    sources.forEach(item => {
        const sessions = Number(item.sessions) || 0;
        const percent = (sessions / max) * 100;

        const row = document.createElement("div");
        row.className = "analytics-item";

        const label = document.createElement("div");
        label.className = "analytics-label";

        const name = document.createElement("span");
        name.textContent = item.traffic_source ?? "Unknown";

        const count = document.createElement("strong");
        count.textContent = sessions;

        label.append(name, count);

        const progress = document.createElement("div");
        progress.className = "progress";

        const bar = document.createElement("div");
        bar.className = "progress-bar";
        bar.style.width = `${percent}%`;

        progress.appendChild(bar);
        row.append(label, progress);
        container.appendChild(row);
    });
}

/* =========================
   DEVICE ANALYSIS
========================= */

function loadDevices(devices) {
    const container = document.getElementById("devices");

    if (!container) return;

    container.replaceChildren();

    if (!Array.isArray(devices) || devices.length === 0) {
        container.textContent = "No device data available.";
        return;
    }

    const max = Math.max(
        ...devices.map(item => Number(item.sessions) || 0),
        1
    );

    devices.forEach(item => {
        const sessions = Number(item.sessions) || 0;
        const percent = (sessions / max) * 100;

        const row = document.createElement("div");
        row.className = "analytics-item";

        const label = document.createElement("div");
        label.className = "analytics-label";

        const name = document.createElement("span");
        name.textContent = item.device ?? "Unknown";

        const count = document.createElement("strong");
        count.textContent = sessions;

        label.append(name, count);

        const progress = document.createElement("div");
        progress.className = "progress";

        const bar = document.createElement("div");
        bar.className = "progress-bar";
        bar.style.width = `${percent}%`;

        progress.appendChild(bar);
        row.append(label, progress);
        container.appendChild(row);
    });
}

/* =========================
   DAILY PERFORMANCE
========================= */

function loadDailyPerformance(daily) {
    const container = document.getElementById("dailyPerformance");

    if (!container) return;

    container.replaceChildren();

    if (!Array.isArray(daily) || daily.length === 0) {
        container.textContent = "No daily data available.";
        return;
    }

    daily.forEach(item => {
        const row = document.createElement("div");
        row.className = "daily-row";

        const date = document.createElement("span");
        date.textContent = item.event_date ?? "";

        const purchases = document.createElement("strong");
        purchases.textContent = item.purchases ?? 0;

        row.append(date, purchases);
        container.appendChild(row);
    });
}

/* =========================
   PURCHASE CHART
========================= */

function createPurchaseChart(daily) {
    const canvas = document.getElementById("purchaseChart");

    if (!canvas || !Array.isArray(daily)) return;

    if (typeof Chart === "undefined") {
        console.error("Chart.js has not loaded.");
        return;
    }

    if (purchaseChart) {
        purchaseChart.destroy();
        purchaseChart = null;
    }

    purchaseChart = new Chart(canvas, {
        type: "line",

        data: {
            labels: daily.map(item => item.event_date),

            datasets: [{
                label: "Purchases",
                data: daily.map(item => Number(item.purchases) || 0),
                tension: 0.3,
                borderWidth: 3,
                fill: false
            }]
        },

        options: {
            responsive: true,
            maintainAspectRatio: false,

            plugins: {
                legend: {
                    display: true
                }
            },

            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        precision: 0
                    }
                }
            }
        }
    });
}

/* =========================
   DATE FILTER
========================= */

function filterDashboard() {
    const select = document.getElementById("dateFilter");

    if (!select || !dashboardData) return;

    const selectedDate = select.value;
    const daily = dashboardData.daily || [];

    const filtered = selectedDate === "all"
        ? daily
        : daily.filter(item => item.event_date === selectedDate);

    createPurchaseChart(filtered);
    loadDailyPerformance(filtered);
}

/* =========================
   BASKET ANALYSIS
========================= */

async function loadBasketAnalysis() {
    const results = document.getElementById("basketResults");

    if (!results) {
        console.error("basketResults element not found.");
        return;
    }

    results.textContent = "Loading basket analysis...";

    try {
        const response = await fetch(`${API_BASE}/basket.php`);

        if (!response.ok) {
            throw new Error(`Basket API HTTP error: ${response.status}`);
        }

        const data = await response.json();
        console.log("Basket Analysis API:", data);

        if (!data.success) {
            throw new Error(data.error || "Basket analysis failed.");
        }

        if (
            !Array.isArray(data.recommendations) ||
            data.recommendations.length === 0
        ) {
            results.textContent =
                "No product pairs found. Add orders containing multiple products.";
            return;
        }

        const summary = document.createElement("p");
        summary.textContent =
            `Total orders analysed: ${data.total_orders}`;

        const tableContainer = document.createElement("div");
        tableContainer.className = "table-container";

        const table = document.createElement("table");
        table.className = "basket-table";

        table.innerHTML = `
            <thead>
                <tr>
                    <th>Product 1</th>
                    <th>Product 2</th>
                    <th>Orders Together</th>
                    <th>Support</th>
                    <th>Confidence (1 → 2)</th>
                    <th>Confidence (2 → 1)</th>
                </tr>
            </thead>
            <tbody></tbody>
        `;

        const tbody = table.querySelector("tbody");

        data.recommendations.forEach(item => {
            const row = document.createElement("tr");

            const values = [
                item.product_1,
                item.product_2,
                item.orders_together,
                `${item.support_percent}%`,
                `${item.confidence_1_to_2}%`,
                `${item.confidence_2_to_1}%`
            ];

            values.forEach(value => {
                const cell = document.createElement("td");
                cell.textContent = value ?? "";
                row.appendChild(cell);
            });

            tbody.appendChild(row);
        });

        tableContainer.appendChild(table);
        results.replaceChildren(summary, tableContainer);

    } catch (error) {
        console.error("Basket Analysis Error:", error);

        results.textContent =
            "Could not load results. Check that WampServer is running and open the dashboard through localhost.";
    }
}




/* =========================
   CSV DATA UPLOAD
========================= */

async function uploadCSV(event) {
    event.preventDefault();

    const fileInput = document.getElementById("csvFile");
    const message = document.getElementById("uploadMessage");
    const file = fileInput.files[0];

    if (!file) {
        message.textContent = "Please select a CSV file.";
        return;
    }

    if (!file.name.toLowerCase().endsWith(".csv")) {
        message.textContent = "Please select a CSV file only.";
        return;
    }

    const formData = new FormData();
    formData.append("csvFile", file);

    message.textContent = "Uploading CSV file...";

    try {
        const response = await fetch(`${API_BASE}/upload.php`, {
            method: "POST",
            body: formData
        });

        const result = await response.json();

        if (!response.ok || !result.success) {
            throw new Error(result.error || "Upload failed.");
        }

        message.textContent = result.message || "CSV uploaded successfully.";

        await loadDashboard();
        await loadFunnelData();
        await loadProducts();

        fileInput.value = "";

    } catch (error) {
        console.error("CSV upload error:", error);
        message.textContent =
            error.message || "Upload failed. Please try again.";
    }
}


/* =========================
   INITIAL LOAD
========================= */

document.addEventListener("DOMContentLoaded", () => {
    loadDashboard();
    loadFunnelData();
    loadProducts();
});