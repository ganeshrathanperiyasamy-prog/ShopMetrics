
<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../helpers/response.php';

try {
    $sql = "
        SELECT
            p.id,
            p.name,
            p.category,
            p.price,
            COALESCE(e.views, 0) AS views,
            COALESCE(e.cart_adds, 0) AS cart_adds,
            COALESCE(o.units_sold, 0) AS units_sold
        FROM products p

        LEFT JOIN (
            SELECT
                product_id,
                COUNT(DISTINCT CASE
                    WHEN event_type = 'product_view'
                    THEN session_id
                END) AS views,
                COUNT(DISTINCT CASE
                    WHEN event_type = 'add_to_cart'
                    THEN session_id
                END) AS cart_adds
            FROM events
            GROUP BY product_id
        ) e ON e.product_id = p.id

        LEFT JOIN (
            SELECT
                product_id,
                SUM(quantity) AS units_sold
            FROM order_items
            GROUP BY product_id
        ) o ON o.product_id = p.id

        ORDER BY views DESC, p.id ASC
    ";

    $products = $pdo->query($sql)->fetchAll();

    foreach ($products as &$product) {
        $product['price'] = (float) $product['price'];
        $product['views'] = (int) $product['views'];
        $product['cart_adds'] = (int) $product['cart_adds'];
        $product['units_sold'] = (int) $product['units_sold'];
    }
    unset($product);

    jsonResponse([
        'success' => true,
        'products' => $products
    ]);

} catch (Throwable $e) {
    jsonResponse([
        'success' => false,
        'error' => 'Unable to load products.'
    ], 500);
}
