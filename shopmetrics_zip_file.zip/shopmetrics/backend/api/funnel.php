<?php

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../helpers/response.php';

try {

    $sql = "
        SELECT
            COUNT(DISTINCT CASE
                WHEN event_type = 'page_view'
                THEN session_id
            END) AS visitors,

            COUNT(DISTINCT CASE
                WHEN event_type = 'product_view'
                THEN session_id
            END) AS product_views,

            COUNT(DISTINCT CASE
                WHEN event_type = 'add_to_cart'
                THEN session_id
            END) AS add_to_cart,

            COUNT(DISTINCT CASE
                WHEN event_type = 'checkout_start'
                THEN session_id
            END) AS checkout,

            COUNT(DISTINCT CASE
                WHEN event_type = 'purchase'
                THEN session_id
            END) AS purchases

        FROM events
    ";

    $result = $pdo->query($sql)->fetch();

    $visitors = (int) $result['visitors'];
    $productViews = (int) $result['product_views'];
    $addToCart = (int) $result['add_to_cart'];
    $checkout = (int) $result['checkout'];
    $purchases = (int) $result['purchases'];

    jsonResponse([
        'success' => true,

        'funnel' => [
            [
                'stage' => 'Visitors',
                'count' => $visitors
            ],
            [
                'stage' => 'Product Views',
                'count' => $productViews
            ],
            [
                'stage' => 'Add to Cart',
                'count' => $addToCart
            ],
            [
                'stage' => 'Checkout',
                'count' => $checkout
            ],
            [
                'stage' => 'Purchases',
                'count' => $purchases
            ]
        ]
    ]);

} catch (Throwable $e) {

    jsonResponse([
        'success' => false,
        'error' => $e->getMessage()
    ], 500);
}