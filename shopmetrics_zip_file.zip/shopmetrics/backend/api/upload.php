
<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../helpers/response.php';

try {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        jsonResponse([
            'success' => false,
            'error' => 'Use POST to upload a CSV file.'
        ], 405);
    }

    if (
        !isset($_FILES['csvFile']) ||
        $_FILES['csvFile']['error'] !== UPLOAD_ERR_OK
    ) {
        jsonResponse([
            'success' => false,
            'error' => 'Please select a valid CSV file.'
        ], 400);
    }

    $file = $_FILES['csvFile']['tmp_name'];
    $handle = fopen($file, 'r');

    if ($handle === false) {
        throw new RuntimeException('Unable to read the CSV file.');
    }

    $headers = fgetcsv($handle);

    if ($headers === false) {
        fclose($handle);
        jsonResponse([
            'success' => false,
            'error' => 'The CSV file is empty.'
        ], 400);
    }

    $headers = array_map(
        static fn($header) => strtolower(trim($header)),
        $headers
    );

    $required = [
        'user_id',
        'session_id',
        'event_type',
        'product_id',
        'event_value',
        'traffic_source',
        'device',
        'country',
        'event_time'
    ];

    if (array_diff($required, $headers)) {
        fclose($handle);
        jsonResponse([
            'success' => false,
            'error' => 'CSV headers do not match the required event columns.'
        ], 400);
    }

    $positions = array_flip($headers);

    $sql = "INSERT INTO events
        (user_id, session_id, event_type, product_id, event_value,
         traffic_source, device, country, event_time)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

    $stmt = $pdo->prepare($sql);
    $inserted = 0;

    $pdo->beginTransaction();

    while (($row = fgetcsv($handle)) !== false) {
        if (count($row) !== count($headers)) {
            throw new RuntimeException('A CSV row has an incorrect number of columns.');
        }

        $get = static fn($key) => trim((string) $row[$positions[$key]]);

        $userId = $get('user_id');
        $sessionId = $get('session_id');
        $eventType = $get('event_type');
        $productId = $get('product_id');
        $eventValue = $get('event_value');
        $trafficSource = $get('traffic_source');
        $device = $get('device');
        $country = $get('country');
        $eventTime = $get('event_time');

        if (
            $userId === '' ||
            $sessionId === '' ||
            $eventType === '' ||
            $trafficSource === '' ||
            $device === '' ||
            $country === '' ||
            $eventTime === ''
        ) {
            throw new RuntimeException('A CSV row is missing a required value.');
        }

        $stmt->execute([
            $userId,
            $sessionId,
            $eventType,
            $productId === '' ? null : (int) $productId,
            $eventValue === '' ? null : (float) $eventValue,
            $trafficSource,
            $device,
            $country,
            $eventTime
        ]);

        $inserted++;
    }

    fclose($handle);
    $pdo->commit();

    jsonResponse([
        'success' => true,
        'message' => "$inserted event rows uploaded successfully.",
        'inserted' => $inserted
    ]);

} catch (Throwable $e) {
    if (isset($pdo) && $pdo->inTransaction()) {
        $pdo->rollBack();
    }

    if (isset($handle) && is_resource($handle)) {
        fclose($handle);
    }

    error_log($e->getMessage());

    jsonResponse([
        'success' => false,
        'error' => 'CSV upload failed. Check the CSV columns and data.'
    ], 500);
}
