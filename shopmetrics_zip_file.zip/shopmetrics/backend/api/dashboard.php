<?php

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../helpers/response.php';

try {

    // Total users
    $users = (int) $pdo
        ->query("SELECT COUNT(DISTINCT user_id) FROM events")
        ->fetchColumn();

    // Total sessions
    $sessions = (int) $pdo
        ->query("SELECT COUNT(DISTINCT session_id) FROM events")
        ->fetchColumn();

    // Total orders
    $orders = (int) $pdo
        ->query("SELECT COUNT(*) FROM orders")
        ->fetchColumn();

    // Total revenue
    $revenue = (float) $pdo
        ->query("SELECT COALESCE(SUM(total_amount), 0) FROM orders")
        ->fetchColumn();

    // Sessions that added products to cart
    $cartSessions = (int) $pdo
        ->query("
            SELECT COUNT(DISTINCT session_id)
            FROM events
            WHERE event_type = 'add_to_cart'
        ")
        ->fetchColumn();

    // Sessions that purchased
    $purchaseSessions = (int) $pdo
        ->query("
            SELECT COUNT(DISTINCT session_id)
            FROM events
            WHERE event_type = 'purchase'
        ")
        ->fetchColumn();

    // Conversion rate
    $conversionRate = $sessions > 0
        ? ($purchaseSessions / $sessions) * 100
        : 0;

    // Average Order Value
    $aov = $orders > 0
        ? $revenue / $orders
        : 0;

    // Cart abandonment
    $cartAbandonment = $cartSessions > 0
        ? (($cartSessions - $purchaseSessions) / $cartSessions) * 100
        : 0;

    // Traffic source performance
    $source = $pdo->query("
        SELECT
            traffic_source,
            COUNT(DISTINCT session_id) AS sessions,
            COUNT(
                DISTINCT CASE
                    WHEN event_type = 'purchase'
                    THEN session_id
                END
            ) AS purchases,
            COALESCE(
                SUM(
                    CASE
                        WHEN event_type = 'purchase'
                        THEN event_value
                        ELSE 0
                    END
                ),
                0
            ) AS revenue
        FROM events
        GROUP BY traffic_source
        ORDER BY revenue DESC
    ")->fetchAll();

    // Device performance
    $device = $pdo->query("
        SELECT
            device,
            COUNT(DISTINCT session_id) AS sessions,
            COUNT(
                DISTINCT CASE
                    WHEN event_type = 'purchase'
                    THEN session_id
                END
            ) AS purchases
        FROM events
        GROUP BY device
        ORDER BY sessions DESC
    ")->fetchAll();

    // Daily performance
    $daily = $pdo->query("
        SELECT
            DATE(event_time) AS event_date,
            COUNT(DISTINCT session_id) AS sessions,
            COUNT(
                DISTINCT CASE
                    WHEN event_type = 'purchase'
                    THEN session_id
                END
            ) AS purchases
        FROM events
        GROUP BY DATE(event_time)
        ORDER BY event_date
    ")->fetchAll();

    // Send response
    jsonResponse([
        'success' => true,

        'kpis' => [
            'users' => $users,
            'sessions' => $sessions,
            'orders' => $orders,
            'revenue' => round($revenue, 2),
            'conversion_rate' => round($conversionRate, 2),
            'aov' => round($aov, 2),
            'cart_abandonment' => round($cartAbandonment, 2)
        ],

        'traffic_sources' => $source,

        'devices' => $device,

        'daily' => $daily
    ]);

} catch (Throwable $e) {

    jsonResponse([
        'success' => false,
        'error' => $e->getMessage()
    ], 500);
}