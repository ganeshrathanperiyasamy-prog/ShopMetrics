
<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../helpers/response.php';

try {
    $sql = "
        SELECT
            oi.order_id,
            p.id AS product_id,
            p.name AS product_name
        FROM order_items oi
        JOIN products p ON p.id = oi.product_id
        ORDER BY oi.order_id
    ";

    $rows = $pdo->query($sql)->fetchAll();

    $baskets = [];
    $productNames = [];

    foreach ($rows as $row) {
        $orderId = $row['order_id'];
        $productId = (int) $row['product_id'];

        $baskets[$orderId][$productId] = true;
        $productNames[$productId] = $row['product_name'];
    }

    $totalOrders = count($baskets);
    $productCounts = [];
    $pairCounts = [];

    foreach ($baskets as $basket) {
        $ids = array_keys($basket);

        foreach ($ids as $id) {
            $productCounts[$id] = ($productCounts[$id] ?? 0) + 1;
        }

        sort($ids);

        for ($i = 0; $i < count($ids); $i++) {
            for ($j = $i + 1; $j < count($ids); $j++) {
                $key = $ids[$i] . '-' . $ids[$j];
                $pairCounts[$key] = ($pairCounts[$key] ?? 0) + 1;
            }
        }
    }

    arsort($pairCounts);
    $recommendations = [];

    foreach ($pairCounts as $key => $count) {
        [$first, $second] = array_map('intval', explode('-', $key));

        $recommendations[] = [
            'product_1' => $productNames[$first],
            'product_2' => $productNames[$second],
            'orders_together' => $count,
            'support_percent' => $totalOrders > 0
                ? round(($count / $totalOrders) * 100, 2)
                : 0,
            'confidence_1_to_2' => !empty($productCounts[$first])
                ? round(($count / $productCounts[$first]) * 100, 2)
                : 0,
            'confidence_2_to_1' => !empty($productCounts[$second])
                ? round(($count / $productCounts[$second]) * 100, 2)
                : 0
        ];
    }

    jsonResponse([
        'success' => true,
        'total_orders' => $totalOrders,
        'recommendations' => $recommendations
    ]);

} catch (Throwable $e) {
    jsonResponse([
        'success' => false,
        'error' => 'Unable to run basket analysis.'
    ], 500);
}
