<?php

declare(strict_types=1);

$host = '127.0.0.1';
$db = 'shopmetrics';
$user = 'root';
$pass = '';
$charset = 'utf8mb4';

$options = [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES => false,
];

try {
    // Connect to MySQL without selecting a database.
    $serverPdo = new PDO(
        "mysql:host=$host;charset=$charset",
        $user,
        $pass,
        $options
    );

    // Create the project database when it does not exist.
    $serverPdo->exec(
        "CREATE DATABASE IF NOT EXISTS `$db`
         CHARACTER SET utf8mb4
         COLLATE utf8mb4_unicode_ci"
    );

    // Count the four tables required by ShopMetrics.
    $requiredTables = ['events', 'orders', 'order_items', 'products'];
    $placeholders = implode(',', array_fill(0, count($requiredTables), '?'));
    $checkTables = $serverPdo->prepare(
        "SELECT COUNT(*)
         FROM information_schema.tables
         WHERE table_schema = ?
         AND table_name IN ($placeholders)"
    );
    $checkTables->execute(array_merge([$db], $requiredTables));
    $tableCount = (int) $checkTables->fetchColumn();

    if ($tableCount === 0) {
        // Fresh database: import the supplied schema and sample data once.
        $schemaFile = dirname(__DIR__, 2) . '/schema.sql';
        if (!is_file($schemaFile)) {
            throw new RuntimeException('schema.sql was not found in the project root.');
        }

        $sql = file_get_contents($schemaFile);
        if ($sql === false || trim($sql) === '') {
            throw new RuntimeException('schema.sql is empty or could not be read.');
        }

        // The SQL dump is run only when none of the required tables exist.
        // This avoids re-importing its DROP TABLE statements into an existing database.
        mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
        $mysqli = new mysqli($host, $user, $pass, $db);
        $mysqli->set_charset($charset);

        try {
            $mysqli->multi_query($sql);
            do {
                if ($result = $mysqli->store_result()) {
                    $result->free();
                }
                if ($mysqli->more_results()) {
                    $mysqli->next_result();
                }
            } while ($mysqli->more_results());
        } finally {
            $mysqli->close();
        }
    } elseif ($tableCount !== count($requiredTables)) {
        // Do not automatically import a dump into a partly populated database.
        throw new RuntimeException(
            'Some required tables are missing from the existing database. '
            . 'Back up the database and import schema.sql manually into a clean database.'
        );
    }

    // API files use this PDO connection variable.
    $pdo = new PDO(
        "mysql:host=$host;dbname=$db;charset=$charset",
        $user,
        $pass,
        $options
    );

} catch (Throwable $e) {
    error_log('ShopMetrics database setup error: ' . $e->getMessage());
    http_response_code(500);
    header('Content-Type: application/json');
    echo json_encode([
        'success' => false,
        'error' => 'Database setup failed. Check the PHP error log.'
    ]);
    exit;
}
