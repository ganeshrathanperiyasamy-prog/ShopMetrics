
from collections import Counter
from itertools import combinations
import pymysql

# Database connection
def get_connection():
    return pymysql.connect(
        host="localhost",
        user="root",
        password="",
        database="shopmetrics",
        cursorclass=pymysql.cursors.DictCursor
    )


def run_basket_analysis():
    try:
        connection = get_connection()

        with connection.cursor() as cursor:
            query = """
                SELECT oi.order_id, p.id AS product_id, p.name AS product_name
                FROM order_items oi
                JOIN products p ON p.id = oi.product_id
                ORDER BY oi.order_id
            """
            cursor.execute(query)
            rows = cursor.fetchall()

        connection.close()

        # Build one basket per order
        baskets = {}
        product_names = {}

        for row in rows:
            order_id = row["order_id"]
            product_id = row["product_id"]
            product_name = row["product_name"]

            baskets.setdefault(order_id, set()).add(product_id)
            product_names[product_id] = product_name

        total_orders = len(baskets)

        print("\n===== ShopMetrics Basket Analysis =====")

        if total_orders == 0:
            print("No order data found. Add sample orders first.")
            return

        # Count products and product pairs
        product_counts = Counter()
        pair_counts = Counter()

        for basket in baskets.values():
            product_counts.update(basket)

            for pair in combinations(sorted(basket), 2):
                pair_counts[pair] += 1

        print(f"\nTotal orders analysed: {total_orders}")

        print("\n--- Most Purchased Products ---")
        for product_id, count in product_counts.most_common():
            name = product_names[product_id]
            print(f"{name}: {count} order(s)")

        print("\n--- Frequently Bought Together ---")

        if not pair_counts:
            print("No orders contain multiple different products yet.")
            print("Add orders with multiple products to find bundles.")
            return

        for (first, second), count in pair_counts.most_common(10):
            support = count / total_orders * 100

            print(
                f"{product_names[first]} + {product_names[second]} | "
                f"Orders: {count} | Support: {support:.1f}%"
            )

        # Association rules: A -> B
        print("\n--- Cross-sell Recommendations ---")

        for (first, second), count in pair_counts.most_common(10):
            confidence = count / product_counts[first] * 100
            reverse_confidence = count / product_counts[second] * 100

            print(
                f"If customer buys {product_names[first]}, "
                f"recommend {product_names[second]} "
                f"(confidence: {confidence:.1f}%)"
            )

            print(
                f"If customer buys {product_names[second]}, "
                f"recommend {product_names[first]} "
                f"(confidence: {reverse_confidence:.1f}%)"
            )

        print("\nBasket analysis completed successfully.")

    except pymysql.MySQLError as error:
        print("Database error:", error)
        print("Check WampServer, database name and table structure.")

    except Exception as error:
        print("Unexpected error:", error)


if __name__ == "__main__":
    run_basket_analysis()
