-- phpMyAdmin SQL Dump
-- version 5.2.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Oct 17, 2026 at 01:34 PM
-- Server version: 8.4.7
-- PHP Version: 8.3.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `shopmetrics`
--

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

DROP TABLE IF EXISTS `events`;
CREATE TABLE IF NOT EXISTS `events` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `session_id` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `event_type` enum('page_view','product_view','add_to_cart','checkout_start','payment','purchase') COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_id` int DEFAULT NULL,
  `event_value` decimal(10,2) DEFAULT '0.00',
  `traffic_source` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `device` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `country` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `event_time` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_session` (`session_id`),
  KEY `idx_user` (`user_id`),
  KEY `idx_event_type` (`event_type`),
  KEY `idx_event_time` (`event_time`),
  KEY `fk_event_product` (`product_id`)
) ENGINE=MyISAM AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`id`, `user_id`, `session_id`, `event_type`, `product_id`, `event_value`, `traffic_source`, `device`, `country`, `event_time`) VALUES
(1, 'U001', 'S001', 'page_view', NULL, 0.00, 'Google', 'Desktop', 'India', '2026-09-01 09:00:00'),
(2, 'U001', 'S001', 'product_view', 1, 799.00, 'Google', 'Desktop', 'India', '2026-09-01 09:01:00'),
(3, 'U001', 'S001', 'add_to_cart', 1, 799.00, 'Google', 'Desktop', 'India', '2026-09-01 09:03:00'),
(4, 'U001', 'S001', 'checkout_start', NULL, 799.00, 'Google', 'Desktop', 'India', '2026-09-01 09:05:00'),
(5, 'U001', 'S001', 'payment', NULL, 799.00, 'Google', 'Desktop', 'India', '2026-09-01 09:06:00'),
(6, 'U001', 'S001', 'purchase', NULL, 3298.00, 'Google', 'Desktop', 'India', '2026-09-01 09:07:00'),
(7, 'U002', 'S002', 'page_view', NULL, 0.00, 'Instagram', 'Mobile', 'India', '2026-09-02 11:00:00'),
(8, 'U002', 'S002', 'product_view', 6, 2999.00, 'Instagram', 'Mobile', 'India', '2026-09-02 11:01:00'),
(9, 'U002', 'S002', 'add_to_cart', 6, 2999.00, 'Instagram', 'Mobile', 'India', '2026-09-02 11:03:00'),
(10, 'U003', 'S003', 'page_view', NULL, 0.00, 'Direct', 'Mobile', 'India', '2026-09-03 13:00:00'),
(11, 'U003', 'S003', 'product_view', 2, 2499.00, 'Direct', 'Mobile', 'India', '2026-09-03 13:01:00'),
(12, 'U003', 'S003', 'add_to_cart', 2, 2499.00, 'Direct', 'Mobile', 'India', '2026-09-03 13:03:00'),
(13, 'U003', 'S003', 'checkout_start', NULL, 2499.00, 'Direct', 'Mobile', 'India', '2026-09-03 13:05:00'),
(14, 'U004', 'S004', 'page_view', NULL, 0.00, 'Google', 'Desktop', 'India', '2026-09-04 15:00:00'),
(15, 'U004', 'S004', 'product_view', 3, 1499.00, 'Google', 'Desktop', 'India', '2026-09-04 15:01:00'),
(16, 'U004', 'S004', 'add_to_cart', 3, 1499.00, 'Google', 'Desktop', 'India', '2026-09-04 15:02:00'),
(17, 'U004', 'S004', 'checkout_start', NULL, 1499.00, 'Google', 'Desktop', 'India', '2026-09-04 15:04:00'),
(18, 'U004', 'S004', 'payment', NULL, 1499.00, 'Google', 'Desktop', 'India', '2026-09-04 15:05:00'),
(19, 'U004', 'S004', 'purchase', NULL, 1499.00, 'Google', 'Desktop', 'India', '2026-09-04 15:06:00'),
(20, 'U005', 'S005', 'page_view', NULL, 0.00, 'Facebook', 'Mobile', 'India', '2026-09-05 17:00:00'),
(21, 'U005', 'S005', 'product_view', 7, 1799.00, 'Facebook', 'Mobile', 'India', '2026-09-05 17:01:00'),
(22, 'U005', 'S005', 'add_to_cart', 7, 1799.00, 'Facebook', 'Mobile', 'India', '2026-09-05 17:02:00'),
(23, 'U001', 'S001', 'page_view', NULL, 0.00, 'Google', 'Desktop', 'India', '2026-10-16 10:00:00'),
(24, 'U001', 'S001', 'product_view', 1, 799.00, 'Google', 'Desktop', 'India', '2026-10-16 10:01:00'),
(25, 'U001', 'S001', 'add_to_cart', 1, 799.00, 'Google', 'Desktop', 'India', '2026-10-16 10:02:00'),
(26, 'U001', 'S001', 'checkout_start', 1, 799.00, 'Google', 'Desktop', 'India', '2026-10-16 10:03:00'),
(27, 'U001', 'S001', 'payment', 1, 799.00, 'Google', 'Desktop', 'India', '2026-10-16 10:04:00'),
(28, 'U001', 'S001', 'purchase', 1, 799.00, 'Google', 'Desktop', 'India', '2026-10-16 10:05:00');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
CREATE TABLE IF NOT EXISTS `orders` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `session_id` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_amount` decimal(10,2) NOT NULL,
  `traffic_source` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `device` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `country` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `order_time` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_order_session` (`session_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `user_id`, `session_id`, `total_amount`, `traffic_source`, `device`, `country`, `order_time`) VALUES
(1, 'U001', 'S001', 3298.00, 'Google', 'Desktop', 'India', '2026-09-01 09:07:00'),
(2, 'U004', 'S004', 1499.00, 'Google', 'Desktop', 'India', '2026-09-04 15:06:00');

-- --------------------------------------------------------

--
-- Table structure for table `order_items`
--

DROP TABLE IF EXISTS `order_items`;
CREATE TABLE IF NOT EXISTS `order_items` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `order_id` int NOT NULL,
  `product_id` int NOT NULL,
  `quantity` int NOT NULL DEFAULT '1',
  `unit_price` decimal(10,2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_order` (`order_id`),
  KEY `idx_product` (`product_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `order_items`
--

INSERT INTO `order_items` (`id`, `order_id`, `product_id`, `quantity`, `unit_price`) VALUES
(1, 1, 1, 1, 799.00),
(2, 1, 2, 1, 2499.00),
(3, 2, 3, 1, 1499.00),
(4, 1, 11, 1, 1399.00);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
CREATE TABLE IF NOT EXISTS `products` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `category`, `price`, `created_at`) VALUES
(1, 'Wireless Mouse', 'Accessories', 799.00, '2026-09-28 15:22:16'),
(2, 'Mechanical Keyboard', 'Accessories', 2499.00, '2026-09-28 15:22:16'),
(3, 'USB-C Hub', 'Accessories', 1499.00, '2026-09-28 15:22:16'),
(4, 'Laptop Stand', 'Accessories', 1199.00, '2026-09-28 15:22:16'),
(5, 'Webcam HD', 'Electronics', 1899.00, '2026-09-28 15:22:16'),
(6, 'Bluetooth Headphones', 'Audio', 2999.00, '2026-09-28 15:22:16'),
(7, 'Laptop Backpack', 'Bags', 1799.00, '2026-09-28 15:22:16'),
(8, 'Power Bank', 'Electronics', 1299.00, '2026-09-28 15:22:16'),
(9, 'Desk Lamp', 'Home Office', 999.00, '2026-09-28 15:22:16'),
(10, 'Notebook', 'Stationery', 199.00, '2026-09-28 15:22:16'),
(11, 'USB Headphones', 'Electronics', 1399.00, '2026-10-16 14:26:00');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
